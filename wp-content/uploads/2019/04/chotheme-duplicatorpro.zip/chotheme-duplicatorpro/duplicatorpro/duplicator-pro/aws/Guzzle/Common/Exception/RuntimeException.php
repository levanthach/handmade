<?php

namespace Guzzle\Common\Exception;

class RuntimeException extends \RuntimeException implements GuzzleException {}
